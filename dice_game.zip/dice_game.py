# Emma Pham Dice Game Extra Credit COSC1336
import random

print('Welcome to the Roll 3 Dice Game!!!')

run = 0
wins = 0 
losses = 0
draw = 0
condition = True
while condition:
    question = input('Roll the Dice? (Y/N) ')
    if question == 'Y' or question == 'y':
        run += 1

        print('Let\'s roll your dice!!!')
        yourdice = [random.randint(1,6), random.randint(1,6), random.randint(1,6)]
        yourdicetotal = yourdice[0] + yourdice[1] + yourdice[2]
        print('----------- ----------- -----------')
        print('|         | |         | |         |')
        print('|         | |         | |         |')
        print('|         | |         | |         |')
        print('----------- ----------- -----------')
        
        print('It\'s AI\'s turn to roll the dice!!!')
        aidice = [random.randint(1,6), random.randint(1,6), random.randint(1,6)]
        aitotal = aidice[0] + aidice[1] + aidice[2]
        print('----------- ----------- -----------')
        print('|         | |         | |         |')
        print('|         | |         | |         |')
        print('|         | |         | |         |')
        print('----------- ----------- -----------')
        
        print('YOU (' + str(yourdicetotal) + ') ' + str(yourdice[0]) + ',' + str(yourdice[1]) + ',' + str(yourdice[2]) + ' - ' + str(aidice[0]) + ',' + str(aidice[1]) + ',' + str(aidice[2]) + ' (' + str(aitotal) + ') AI')
        if yourdicetotal > aitotal:
            wins += 1
            print('\nYou win!!!')
        elif aitotal > yourdicetotal:
            losses += 1
            print('\nAI wins...')
        else:
            draw += 1
            print('\nDraw?!!')
        rate = wins / (wins + losses + draw) 
        print(f'GRAND TOTAL AFTER THE RUN #{run}:   YOU {wins} - {losses} AI (Win Ratio: {rate:.3f}) ')
    elif question == 'N' or question == 'n':
        condition = False

print('See ya!!!')