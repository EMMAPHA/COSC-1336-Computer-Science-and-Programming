"""  
Chapter 10:  Exercise 3

Starting with the list of the previous exercise, write Python statements 
to do the following:
    a. Append “apple” and 76 to the list.
    b. Insert the value “cat” at position 3.
    c. Insert the value 99 at the start of the list.
    d. Find the index of “hello”.
    e. Count the number of 76s in the list.
    f. Remove the first occurrence of 76 from the list.
    g. Remove True from the list using pop and index.
"""

myList = [76, 92.3, 'hello', True, 4, 76]

# Append “apple” and 76 to the list
myList.append("apple")
myList.append(76)
print(myList)   # [76, 92.3, 'hello', True, 4, 76, 'apple', 76]

# Insert the value “cat” at position 3
myList.insert(3, "cat")
print(myList)   # [76, 92.3, 'hello', 'cat', True, 4, 76, 'apple', 76]

# Insert the value 99 at the start of the list
myList.insert(0, 99)
print(myList)   # [99, 76, 92.3, 'hello', 'cat', True, 4, 76, 'apple', 76]

# Find the index of “hello”
ind = myList.index("hello")
print(ind)      # 3

# Count the number of 76s in the list
cnt = myList.count(76)
print(cnt)      # 3

# Remove the first occurrence of 76 from the list
myList.remove(76)
print(myList)   # [99, 92.3, 'hello', 'cat', True, 4, 76, 'apple', 76]

# Remove True from the list using pop and index
myList.pop(myList.index(True))
print(myList)   # [99, 92.3, 'hello', 'cat', 4, 76, 'apple', 76]