"""  
Chapter 10:  Exercise 14

Write a function replace(s, old, new) that replaces all occurences 
of old with new in a string s:
"""

def replace(s, old, new):
    while s.count(old) != 0:
        s = s[:s.find(old)] + new + s[s.find(old)+len(old):]
    print(s)

# Example from the textbook
replace('Mississippi', 'i', 'I')    # 'MIssIssIppI'

s = 'I love spom!  Spom is my favorite food.  Spom, spom, spom, yum!'
replace(s, 'om', 'am')
# 'I love spam!  Spam is my favorite food.  Spam, spam, spam, yum!'
replace(s, 'o', 'a')
# 'I lave spam!  Spam is my favarite faad.  Spam, spam, spam, yum!'