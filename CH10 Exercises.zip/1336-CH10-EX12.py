"""  
Chapter 10:  Exercise 12

Count how many words occur in a list up to and including the first 
occurrence of the word “sam”.
"""

# My answer with 'for' loop
def count(lst):
    total = 0
    for i in lst:
        total += 1
        if i == "sam":
            return total
    return total

# My answer with 'while' loop
def count2(lst):
    total = 0
    index = 0
    while index < len(lst):
        total += 1
        if lst[index] == "sam":
            return total
        index += 1
    return total

# Example from the textbook
list = ["ham", "lam", "bam", "sam", "dam", "yam"]
print(count(list))  # 4
print(count2(list)) # 4