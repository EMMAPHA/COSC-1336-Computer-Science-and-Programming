"""  
Chapter 10:  Exercise 5

Write a Python function named max that takes a parameter containing 
a nonempty list of integers and returns the maximum value. 
(Note: there is a builtin function named max but pretend you cannot use it.)
"""

def max(lst):
    if len(lst) != 0:
        themax = lst[0]     # Or themax = 0
        for i in lst:
            if i > themax:
                themax = i
        return themax

print(max([3, 31, 5, 7]))    # 31
print(max([3, 13, 51, 7]))   # 51