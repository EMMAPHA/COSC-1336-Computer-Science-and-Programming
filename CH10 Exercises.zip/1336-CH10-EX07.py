"""  
Chapter 10:  Exercise 7

Write a function to count how many odd numbers are in a list.
"""

def countOdd(lst):
    cnt = 0
    for i in lst:
        if i%2: # or i%2 == 1
            cnt += 1
    return cnt

# Examples from the textbook
print(countOdd([1,3,5,7,9]))        # 5
print(countOdd([-1,-2,-3,-4,-5]))   # 3
print(countOdd([2,4,6,8,10]))       # 0
print(countOdd([0,-1,12,-33]))      # 2

# My own example: Make a random list of 10 elements to test the function
from random import randint
lst = []
for i in range(10):
    lst.append(randint(0, 1000))
print(f"{lst} >> Number of odd elements = {countOdd(lst)}")