"""  
Chapter 10:  Exercise 17

Create a list named randlist containing 100 random integers 
between 0 and 1000 (use iteration, append, and the random module).
"""

from random import randint

randlist = []
for i in range(100):
    randlist.append(randint(0,1000))
print(randlist)