"""  
Chapter 10:  Exercise 8

Sum up all the even numbers in a list.
"""

def sumEven(lst):
    total = 0
    for i in lst:
        if i%2 == 0:
            total += i
    return total

# Examples from the textbook
print(sumEven([1,3,5,7,9]))         # 0
print(sumEven([-1,-2,-3,-4,-5]))    # -6
print(sumEven([2,4,6,7,9]))         # 12
print(sumEven([0,1,12,33]))         # 12

# My own example: Make a random list of 10 elements to test the function
from random import randint
lst = []
for i in range(10):
    lst.append(randint(0, 1000))
print(f"{lst} >> Sum of all even elements = {sumEven(lst)}")