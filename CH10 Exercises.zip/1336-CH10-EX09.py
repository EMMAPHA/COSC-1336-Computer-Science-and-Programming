"""  
Chapter 10:  Exercise 9

Sum up all the negative numbers in a list.
"""

def sumNegatives(lst):
    sum = 0
    for i in lst:
        if i < 0:
            sum += i
    return sum

# Examples from the textbook
print(sumNegatives([-1,-2,-3,-4,-5]))   # -15
print(sumNegatives([1,-3,5,-7,9]))      # -10
print(sumNegatives([-2,-4,6,-7,9]))     # -13
print(sumNegatives([0,1,2,3,4]))        # 0

# My own example: Make a random list of 10 elements to test the function
from random import randint
lst = []
for i in range(10):
    lst.append(randint(-100, 100))
print(f"{lst} >> Sum of all negative elements = {sumNegatives(lst)}")