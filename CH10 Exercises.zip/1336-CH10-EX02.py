"""  
Chapter 10:  Exercise 2

Create a list called myList with the following six items: 
76, 92.3, “hello”, True, 4, 76. 
Begin with the empty list shown below, and add 6 statements to add 
each item, one per item. The first three statements should use the 
append method to append the item to the list, and the last three 
statements should use concatenation.
"""

# Use for loops to append/concatenate elements into the list
myList = []

for i in [76, 92.3, "hello"]:
    myList.append(i)

for i in [True, 4, 76]:
    myList += [i]

print(myList)   # [76, 92.3, 'hello', True, 4, 76]

# Or append/concatenate elements into the list one at a time
myList2 = []

myList2.append(76)
myList2.append(92.3)
myList2.append("hello")
myList2 += [True]
myList2 += [4]
myList2 += [76]

print(myList2)  # [76, 92.3, 'hello', True, 4, 76]