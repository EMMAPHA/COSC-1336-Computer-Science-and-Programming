"""  
Chapter 10:  Exercise 13

Although Python provides us with many list methods, it is good practice 
and very instructive to think about how they are implemented. Implement 
a Python function that works like the following:

    a. count
    b. in
    c. reverse
    d. index
    e. insert
"""

# Both my and textbook answer
def count(item, list):
    total = 0
    for i in list:
        if i == item:
            total += 1
    return total

# Both my and textbook answer
def is_in(item, list):
    for i in list:
        if i == item:
            return True
    return False

# Textbook answer - In 'for' loop, look up elements in a reversed order
def reverse(lst):
    reversed = []
    for i in range(len(lst)-1, -1, -1): # Step through the original list backwards
        reversed.append(lst[i])
    return reversed

# My answer - In 'for' loop, concatenate the element in a reversed order
def reverse2(list):
    mylist = []
    for i in list:
        mylist = [i] + mylist
    return mylist

# Textbook answer - In 'for' loop, look up the index numbers
def index(item, list):
    for i in range(len(list)):
        if list[i] == item:
            return i
    return -1

# My answer - In 'for' loop, look up the elements
def index2(item, list):
    ind = 0
    for i in list:
        if i == item:
            return ind
        ind += 1
    return -1

# Textbook answer
# Use 'for' loop and append the element in the designated index number
def insert(obj, index, lst):
    newlst = []
    for i in range(len(lst)):
        if i == index:
            newlst.append(obj)
        newlst.append(lst[i])
    return newlst

# My answer
# Slice the list and concatenate the element in the designated index number
def insert2(item, pos, list):
    return list[:pos] + [item] + list[pos:]

# Example from the textbook
lst = [0, 1, 1, 2, 2, 3, 4, 5, 6, 7, 8, 9]
print(count(1, lst))            # 2
print(is_in(4, lst))            # True
print(reverse(lst))             # [9, 8, 7, 6, 5, 4, 3, 2, 2, 1, 1, 0]
print(reverse2(lst))            # [9, 8, 7, 6, 5, 4, 3, 2, 2, 1, 1, 0]
print(index(2, lst))            # 3
print(index2(2, lst))           # 3
print(insert('cat', 4, lst))    # [0, 1, 1, 2, 'cat', 2, 3, 4, 5, 6, 7, 8, 9
print(insert2('cat', 4, lst))   # [0, 1, 1, 2, 'cat', 2, 3, 4, 5, 6, 7, 8, 9