"""  
Chapter 10:  Exercise 10

Count how many words in a list have length 5.
"""

def countWords(lst):
    cnt = 0
    for i in lst:
        if len(i) == 5:
            cnt += 1
    return cnt

# My own example
alist = ["hello", 'hi', 'yours', 'his', 'hose', 'house']
print(countWords(alist))    # 3