"""  
Chapter 10:  Exercise 11

Sum all the elements in a list up to but not including the first even number.
"""

# Textbook answer
def sumUntilEven(lst):
    sum = 0
    index = 0
    while index < len(lst) and lst[index]%2 != 0: 
        sum += lst[index]
        index += 1
    return sum

# My answer
def sumUntilEven2(lst):
    sum = 0
    for i in lst:
        if i%2 == 0:
            return sum
        sum += i
    return sum

# Example from the textbook
from random import randint
lst = []
for i in range(100):
    lst.append(randint(0,1000))
print(lst)
print(sumUntilEven(lst))
print(sumUntilEven2(lst))