"""  
Chapter 10:  Exercise 4

Write a function called average that takes a list of numbers as 
a parameter and returns the average of the numbers.
"""

from random import randint

# For the question 4, completing this function is enough.
def average(numlist):
    total = 0
    for i in numlist:
        total += i
    return total/len(numlist)

# I write below codes to make it more interesting.
# Below codes create 10 random integers elements between 0 and 100
#
# Here is an example output
# :
# My list: [55, 69, 52, 95, 87, 10, 55, 37, 27, 27]
# The average of my list is 51.40.
mylist = []
for i in range(10):
    mylist.append(randint(0,100))
print(f"\nMy list: {mylist}\nThe average of my list is {(average(mylist)):.2f}.\n")